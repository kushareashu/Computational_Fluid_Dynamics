
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){

   int j,m=101;

   float Re,U,H,dt,dy,u[m],un[m];

    Re = 100;
    U = 1.0;
    H = 1.0;
    dt = 0.01;
    dy = H/(m-1);
    
   float aj,bj,cj,gama,d[m],P[m],Q[m];
    
    gama =  dt/(Re*dy*dy);
    
    aj = -(1+gama);
    bj = gama/2;
    cj = gama/2;
    
    

    un[1] = 0.0;    //BCs
    un[m] = U;

    for(j=2; j<m; j++){

        un[j] = 0.0;
    }
    u[m]=U;
    
     for(j=1; j<m; j++){

        u[j] = 0.0;
    }
    
    FILE *ptr = fopen("Steady_Crank.dat","w");

    fprintf(ptr,"TITLE = VELOCITY\nVARIABLES = \"u\", \"y\"\nZone T = \"BLOCK1\", j=%d, F=POINT\n",m);

    
    d[1]=-u[1];  //Crank Nicloson TDMA
    d[m]=-u[m];
    P[1]=-bj/aj;
    P[m]=0.0;
    Q[1]=d[1]/aj;
    Q[m]=u[m];

    double error = 0.0;
    int iteration=0;

   do{

    for(j=2; j<m; j++){

        d[j]=(gama-1)*u[j]-(gama/2)*(u[j+1]+u[j-1]);

        P[j]=-(bj/(aj+(cj*P[j-1])));
            
        Q[j]=(d[j]-(cj*Q[j-1]))/(aj+(cj*P[j-1]));
    }
    
    for(j=(m-1); j>1; j--){

        un[j] = P[j] * un[j+1] + Q[j];
    } 

    error =0.0;

    for(j=1; j<=m; j++){

        error = error + pow((un[j]-u[j]),2);
    }
    error = sqrt(error/m);

    for(j=1; j<=m; j++){

        u[j] = un[j];
    }
    iteration++;

    }while(error > 0.000001);
    
    for(j=1; j<=m; j++){

        fprintf(ptr,"%f\t\t%f\n", un[j], (j-1)*dy);
    }

    fclose(ptr);
    
    printf("Number of iterations = %d\n",iteration);

    printf("The Data file has been created");




    return 0;
}

