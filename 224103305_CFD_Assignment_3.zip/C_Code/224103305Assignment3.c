#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main(){

double dx,dy;
double e,en,ed,emax= pow(10,-6); 
int x=101,y=101,it=0; 
double Re,U=1; 
int i,j;

printf("Value of Reynolds Number = ");
scanf("%lf",&Re);

dx=pow((x-1),-1); 
dy=pow((y-1),-1);

double beta=dx/dy; 

FILE *ptr1 = fopen("Streamfunction.dat","w");       
FILE *ptr2 = fopen("Centerline_U_Plot.dat","w");    
FILE *ptr3 = fopen("Centerline_V_Plot.dat","w");    
FILE *ptr4 = fopen("Vector_U.dat","w");            
FILE *ptr5 = fopen("Vector_V.dat","w");             


fprintf(ptr1,"TITLE = STREAM FUNCTION \n VARIABLES = \"x\", \"y\", \"phi\"\n");
fprintf(ptr1,"Zone T = \"BLOCK1\", i=101, j=101, F=POINT\n\n");
fprintf(ptr2,"TITLE = u_centerline \n VARIABLES = \"y\", \"u\"");
fprintf(ptr2,"Zone T = \"BLOCK1\", F=POINT\n\n");
fprintf(ptr3,"TITLE = v_centerline\n VARIABLES = \"x\", \"v\"");
fprintf(ptr3,"Zone T = \"BLOCK1\", F=POINT\n\n");
fprintf(ptr4,"TITLE = u_vectors\nVARIABLES = \"x\", \"y\", \"U\"");
fprintf(ptr4,"Zone T = \"BLOCK1\", i=101, j=101, F=POINT\n\n");
fprintf(ptr5,"TITLE = v_vectors\nVARIABLES = \"x\", \"y\", \"V\"");
fprintf(ptr5,"Zone T = \"BLOCK1\", i=101, j=101, F=POINT\n\n");

double w[y][x],w1[y][x],S[y][x],Sp[y][x]; 
double u[y][x],v[y][x]; 

for(i=0; i<x; i++){

for(j=0; j<y; j++){

S[j][i]=0;
w[j][i]=0;
w1[j][i]=0;
u[j][i]=0;
v[j][i]=0;
}
}


for(i=1; i<y-1; i++){

w[y-1][i]=-(2*U/dy);
w1[y-1][i]=-(2*U/dy);

}

do{

en=0; 
ed=0;  


for(j=0; j<y; j++){

for(i=0; i<x; i++){

w1[j][i]=w[j][i]; 
}
}


for(j=1; j<y-1; j++){

for(i=1; i<x-1; i++){

S[j][i]=(S[j][i+1]+S[j][i-1]+(beta*beta)*(S[j+1][i]+S[j-1][i])+(dx*dx)*w[j][i])/(2*(1+pow(beta,2)));
}
}


for(j=1; j<x-1; j++){

w[j][0]=-(2*S[j][1])/pow(dx,2); 
w[j][x-1]=-(2*S[j][x-2])/pow(dx,2);
}


for(i=1; i<x-1; i++){

w[0][i]=-(2*S[1][i])/pow(dy,2);
w[y-1][i]=-(2*S[y-2][i]+2*dy*U)/pow(dy,2);
}


for(j=1; j<y-1; j++){

for(i=1; i<x-1; i++){

w[j][i]=(w[j][i+1]+w[j][i-1]+(beta*beta)*(w[j+1][i]+w[j-1][i])-(0.25*Re*beta*(w[j][i+1]-
w[j][i-1]) *(S[j+1][i]-S[j-1][i])) + (0.25*Re*beta*(w[j+1][i]-w[j-1][i])*(S[j][i+1]-S[j][i-1])))/(2*(1+pow(beta,2)));
}
}


for(j=0; j<y; j++){

for(i=0; i<x; i++){

en=en+fabs(w[j][i]-w1[j][i]); 
ed=ed+fabs(w1[j][i]); 
}
}


e=en/ed ;
it++;
}while(e>emax);

printf("number of iterations =  %d \n",it);


for(j=1; j<y-1; j++){

for(i=1; i<x-1; i++){

u[j][i]=(S[j+1][i]-S[j-1][i])/(2*dx); 
v[j][i]=-1*(S[j][i+1]-S[j][i-1])/(2*dy);
}


}
for(i=0; i<y; i++){

u[y-1][i]=U;
}

for(j=0; j<y; j++){

for(i=0; i<x; i++){

fprintf(ptr1,"%lf \t %lf \t %lf\t\n",j*dx,i*dy,S[i][j]);
fprintf(ptr4,"%lf \t %lf \t %lf\t\n",j*dx,i*dy,u[i][j]);
fprintf(ptr5,"%lf \t %lf \t %lf\t\n",j*dx,i*dy,v[i][j]);
}
}


for(i=0; i<x; i++){

fprintf(ptr2,"%lf \t %lf \n",u[i][50],i*dy);
fprintf(ptr3,"%lf \t %lf \n",i*dx,v[50][i]);


}

    return 0;
    
}